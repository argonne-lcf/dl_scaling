#define __NR_io_setup		206
#define __NR_io_destroy		207
#define __NR_io_getevents	208
#define __NR_io_submit		209
#define __NR_io_cancel		210
